package com.example.todolistc.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TodolistDto {

    private Long id;
    private String content;
    private String date;

}

