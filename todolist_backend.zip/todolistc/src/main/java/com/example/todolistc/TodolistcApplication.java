package com.example.todolistc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodolistcApplication {

    public static void main(String[] args) {
        SpringApplication.run(TodolistcApplication.class, args);
    }

}
