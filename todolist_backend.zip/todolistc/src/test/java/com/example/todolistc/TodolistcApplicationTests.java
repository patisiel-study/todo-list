package com.example.todolistc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodolistcApplicationTests {

    @Test
    void contextLoads() {
    }

}
